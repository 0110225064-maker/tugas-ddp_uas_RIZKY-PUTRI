from django.shortcuts import render

def home(request):
    context = {
        'name': 'Rizky Putri',
        'title': 'Mahasiswa',
        'email': 'putririzky5@gmail.com',
        'phone': '+62 821-6061-5416',
        'location': 'Medan, Indonesia',
        'description': 'Halo! Aku mahasiswi Teknik Informatika semester awal di STT NF. Lagi seru-serunya eksplor dunia web development, terutama bikin tampilan yang rapi pakai HTML/CSS dan asah logika lewat coding. Sehari-hari nggak jauh dari VS Code dan Git buat ngerjain project. Aku tipe yang happy banget belajar hal baru dan terbuka banget buat kolaborasi bareng di project teknologi yang keren. Let’s connect and grow together! ✨.',
        'social_links': {
            'github': 'https://github.com/raflyyz',
        }
    }
    return render(request, 'profile_app/home.html', context)

def about(request):
    context = {
        'education': [
            {
                'degree': 'SD',
                'institution': 'SDN 0104 Sibuhuan',
                'year': '2012 - 2018',
                'description': 'Mengikuti Lomba Pramuka'
            },
            {
                'degree': 'MTSN',
                'institution': 'MTSN 1 Padang Lawas',
                'year': '2019 - 2022',
                'description': 'Mengikuti Lomba Nari'
            },
            {
                'degree': 'SMA ',
                'institution': 'SMA Negeri 1 Barunmun',
                'year': '2022 - 2025',
                'description': 'Lomba Melukis.'
            },
            {
                'degree': 'Mahasiswa Teknik Informatika',
                'institution': 'STT Nurul Fikri',
                'year': '2025 - Sekarang',
                'description': ''
            }
            
        ],
        'organizations': [
            {
                'role': 'Humas',
                'organization': 'Pramuka',
                'period': '2024-2025',
                'description': 'Saya pernah menjadi Humas Pramuka di Sekolah.'
            }
        ]
    }
    return render(request, 'profile_app/about.html', context)

def gallery(request):
    context = {
        'gallery_items': [
            {
                'title': 'Lomba Clasmeet',
                'description': 'Mengikuti Lomba Clasmeet Antar Sekolah se-Kabupaten Padang Lawas',
                'image': 'images/clssmett.jpg',
                'date': '2024-2025'
            },
            {
                'title': 'Lomba Oliempade',
                'description': 'Mengikuti Lomba Oliempade Bahasa Indonesia Tingkat Nasional',
                'image': 'images/indo.jpg',
                'date': '2025'
            },
            {
                'title': 'Lomba Oliempade',
                'description': 'Lomba Melukis Antar sekolah se-Kabupaten Padang Lawas',
                'image': 'images/melukis.jpg',
                'date': '2025'
            },
            {
                'title': 'Lomba ',
                'description': 'Mengikuti Lomba Menari Antar Sekolah se-Kabupaten Padang Lawas',
                'image': 'images/nari.jpg',
                'date': '2023'
            }
        ]
    }
    return render(request, 'profile_app/gallery.html', context)