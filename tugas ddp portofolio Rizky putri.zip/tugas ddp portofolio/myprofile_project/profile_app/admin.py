from django.contrib import admin

# Admin configuration dapat ditambahkan di sini
