# Django Profile Website

Website profile pribadi yang dibangun dengan Django dan Bootstrap 5.

## Fitur
- Homepage dengan informasi profile
- Halaman About dengan riwayat pendidikan & organisasi
- Gallery untuk dokumentasi kegiatan
- Responsive design (mobile-friendly)
- Modern UI dengan animasi

## Instalasi

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Jalankan migrasi:
```bash
python manage.py migrate
```

3. Buat superuser (opsional):
```bash
python manage.py createsuperuser
```

4. Jalankan development server:
```bash
python manage.py runserver
```

5. Buka browser di: http://127.0.0.1:8000/

## Struktur Project
```
myprofile_project/
├── myprofile/              # Project settings
├── profile_app/            # Main application
├── templates/              # HTML templates
├── static/                 # Static files (CSS, JS, images)
├── media/                  # User uploaded files
└── manage.py              # Django management script
```

## Kustomisasi

Edit file `profile_app/views.py` untuk mengubah:
- Data profile pribadi
- Riwayat pendidikan
- Pengalaman organisasi
- Gallery items

## Teknologi
- Django 4.2
- Bootstrap 5.3
- AOS Animation
- Bootstrap Icons
